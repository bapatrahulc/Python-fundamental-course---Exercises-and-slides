def add_spam(menu=None):
     if menu is None:
         menu = []
    menu.append('spam')
    return menu
