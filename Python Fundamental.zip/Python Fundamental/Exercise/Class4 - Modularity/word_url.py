
# coding: utf-8

# In[ ]:
import sys
from urllib.request import urlopen

def words_fetch(url):
    
    with urlopen(url) as story:
        story_words = []
        for line in story:
            line_words = line.split()
            for word in line_words:
                story_words.append(word) 
    return story_words

def print_words(story_words):
    for word in story_words:
        print(word)

def main():
    url = sys.argv[1]
    words = words_fetch(url)
    print_words(words)
    
if __name__ == '__main__':
    main()
    
  