
# coding: utf-8

# In[ ]:

from urllib.request import urlopen
from collections import Counter

def words_fetch():
    
    with urlopen('http://sixty-north.com/c/t.txt') as story:
        story_words = []
        for line in story:
            line_words = line.split()
            for word in line_words:
                story_words.append(word) 
    return story_words

''' Option 1 - Set() to print unique words. Sorted() sorts the words. 
def print_unique_words(story_words):
    mylist = []
    mylist = list(sorted(set(story_words)))
    print(mylist)
'''

def print_unique_words(story_words):
    mylist = []
    mylist = list(sorted(set(story_words)))
    print(mylist)







''' Option 2 - Unique values and counts 
def print_unique_words(story_words):
    c = Counter (story_words)
    print(c.items())
'''



def main():
    words = words_fetch()
    print_unique_words(words)
    
if __name__ == '__main__':
    main()
    
  