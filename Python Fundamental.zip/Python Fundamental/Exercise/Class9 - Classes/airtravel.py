''' Model for aircraft flights '''

class Flight:

# initializer method - __init__(). Not a constructor. Analogous to = 'this' in C++

#_number ==> Not to confuse with number() and define it as a variable which user cannot modify or access - private in java
    def __init__(self, number):
        self._number = number
            
    def number(self):
        return self._number
    

