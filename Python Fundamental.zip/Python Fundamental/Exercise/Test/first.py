num = 2
