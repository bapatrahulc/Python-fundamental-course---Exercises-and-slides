n = [1, 2, 3, 4]

for x in n:
    x = x + 15
    print (x)
    
    
