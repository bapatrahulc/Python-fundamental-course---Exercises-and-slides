n = 2
if (n == 2):
    print ("equal")
else:
    print ("Not equal")
    

while (n < 10):
    if (n == 8):
        break
    print (n)
    n = n + 1
    
    
